export class OrderDetail {

    name !: string;
    price !: number;
    quantity !: number;
    subTotal !:number;

}
